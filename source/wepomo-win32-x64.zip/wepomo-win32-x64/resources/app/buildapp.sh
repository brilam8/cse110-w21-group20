#!/bin/bash

echo "running electron-packager"

npx electron-packager . wepomo --platform=win32 --icon "./logo/logo.ico"

zip -r wepomo-win32-x64.zip wepomo-win32-x64

rm -r wepomo-win32-x64
