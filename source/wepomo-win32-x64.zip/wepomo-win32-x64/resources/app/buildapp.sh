#!/bin/bash

echo "running electron-packager"

npx electron-packager . wepomo --platform=win32 --icon "./logo/logo.ico"
