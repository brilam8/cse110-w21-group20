#!/bin/bash

echo "starting up cypress"
./node_modules/.bin/cypress open