document.getElementById("to-home-page").addEventListener('click', ()=> {
    // window.location.replace("./landing-page.html"); //better but only when landing page is finished
    window.location.href = "./landing-page.html";
  });

  document.getElementById("to-set-up-page").addEventListener('click', ()=> {
    window.location.href = "./setup-active-break-pages.html";
  });
